export const environment = {
  production: true,
  apiUrl: 'http://164.52.216.127:1086/api/',
};

