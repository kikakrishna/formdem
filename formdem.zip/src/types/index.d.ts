export {};

declare global {
  interface Window {
    cdw:any;
    perks:any;
    perkinelmer:any;
  }
}