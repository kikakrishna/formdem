export const logo = `<svg width="48" height="48" viewBox="0 0 48 48">
    <defs>
      <linearGradient id="linear-gradient" x1="-1.538" y1="0.545" x2="1.462" y2="0.479" gradientUnits="objectBoundingBox">
        <stop offset="0" stop-color="#233c6d"/>
        <stop offset="0.04" stop-color="#233c6d"/>
        <stop offset="1" stop-color="#376acf"/>
      </linearGradient>
      <linearGradient id="linear-gradient-2" x1="0.217" y1="1.149" x2="0.755" y2="-0.084" gradientUnits="objectBoundingBox">
        <stop offset="0" stop-color="#233c6d"/>
        <stop offset="0.04" stop-color="#233c6d"/>
        <stop offset="1" stop-color="#386dd5"/>
      </linearGradient>
      <linearGradient id="linear-gradient-3" x1="0.181" y1="1.002" x2="0.821" y2="0.161" gradientUnits="objectBoundingBox">
        <stop offset="0" stop-color="#233c6d"/>
        <stop offset="0.04" stop-color="#233c6d"/>
        <stop offset="1" stop-color="#3b74e5"/>
      </linearGradient>
      <radialGradient id="radial-gradient" cx="0.5" cy="0.5" r="0.495" gradientUnits="objectBoundingBox">
        <stop offset="0.13" stop-color="#3280fc"/>
        <stop offset="1"/>
      </radialGradient>
      <linearGradient id="linear-gradient-4" y1="0.5" x2="1" y2="0.5" gradientUnits="objectBoundingBox">
        <stop offset="0" stop-color="#030d14"/>
        <stop offset="1" stop-color="#0b2f45"/>
      </linearGradient>
      <linearGradient id="linear-gradient-6" x1="-0.553" y1="0.653" x2="0.997" y2="0.428" gradientUnits="objectBoundingBox">
        <stop offset="0" stop-color="#233c6d"/>
        <stop offset="0.04" stop-color="#243e70"/>
        <stop offset="1" stop-color="#376cd5"/>
      </linearGradient>
      <clipPath id="clip-virtual_assisst">
        <rect width="48" height="48"/>
      </clipPath>
    </defs>
    <g id="virtual_assisst" data-name="virtual assisst" clip-path="url(#clip-virtual_assisst)">
      <g id="Group_756" data-name="Group 756" transform="translate(10358.293 18848.711)">
        <rect id="Rectangle_1310" data-name="Rectangle 1310" width="1.45" height="9.518" transform="translate(-10335.02 -18846.219)" fill="url(#linear-gradient)"/>
        <rect id="Rectangle_1309" data-name="Rectangle 1309" width="12.691" height="6.255" rx="3.127" transform="translate(-10340.64 -18837.697)" fill="url(#linear-gradient-2)"/>
        <path id="Rectangle_1308" data-name="Rectangle 1308" d="M23.031,0h0A22.382,22.382,0,0,1,45.413,22.382v5.99a6.163,6.163,0,0,1-6.163,6.163H6.163A6.163,6.163,0,0,1,0,28.372V23.031A23.031,23.031,0,0,1,23.031,0Z" transform="translate(-10357 -18834.707)" fill="url(#linear-gradient-3)"/>
        <path id="Path_656" data-name="Path 656" d="M138.342,233.777h0a4.38,4.38,0,0,1-1.938.448H109.151a4.379,4.379,0,0,1-1.937-.448h0a3.584,3.584,0,0,1-2.077-3.673l.015-.108c.7-5.062,5.284-8.954,10.9-9.247,2.378-.124,4.874-.187,7.478-.173q3.059.018,5.908.169c5.642.291,10.261,4.168,10.961,9.249l.015.109A3.584,3.584,0,0,1,138.342,233.777Z" transform="translate(-10457.071 -19045.408)" fill="#fff"/>
        <g id="Group_748" data-name="Group 748" transform="translate(-10346.614 -18822.578)">
          <ellipse id="Ellipse_194" data-name="Ellipse 194" cx="5.139" cy="5.139" rx="5.139" ry="5.139" fill="url(#radial-gradient)" style="mix-blend-mode: screen;isolation: isolate"/>
          <g id="Group_736" data-name="Group 736" transform="translate(1.45 1.45)">
            <ellipse id="Ellipse_195" data-name="Ellipse 195" cx="3.689" cy="3.689" rx="3.689" ry="3.689" fill="#eefdff"/>
          </g>
          <g id="Group_737" data-name="Group 737" transform="translate(2.041 2.041)">
            <ellipse id="Ellipse_196" data-name="Ellipse 196" cx="3.098" cy="3.098" rx="3.098" ry="3.098" fill="url(#linear-gradient-4)"/>
          </g>
          <g id="Group_738" data-name="Group 738" transform="translate(4.828 3.188)">
            <path id="Path_644" data-name="Path 644" d="M122.609,229.858a1.148,1.148,0,1,1-1.148-1.148A1.148,1.148,0,0,1,122.609,229.858Z" transform="translate(-120.314 -228.71)" fill="#eefdff"/>
          </g>
          <g id="Group_739" data-name="Group 739" transform="translate(4.223 7.057)">
            <ellipse id="Ellipse_197" data-name="Ellipse 197" cx="0.458" cy="0.458" rx="0.458" ry="0.458" fill="#eefdff"/>
          </g>
          <g id="Group_740" data-name="Group 740" transform="translate(3.088 6.599)">
            <path id="Path_645" data-name="Path 645" d="M118.171,234.035a.229.229,0,1,1-.229-.229A.229.229,0,0,1,118.171,234.035Z" transform="translate(-117.713 -233.806)" fill="#eefdff"/>
          </g>
        </g>
        <g id="Group_749" data-name="Group 749" transform="translate(-10332.732 -18822.578)">
          <ellipse id="Ellipse_198" data-name="Ellipse 198" cx="5.139" cy="5.139" rx="5.139" ry="5.139" fill="url(#radial-gradient)" style="mix-blend-mode: screen;isolation: isolate"/>
          <g id="Group_742" data-name="Group 742" transform="translate(1.45 1.45)">
            <ellipse id="Ellipse_199" data-name="Ellipse 199" cx="3.689" cy="3.689" rx="3.689" ry="3.689" fill="#eefdff"/>
          </g>
          <g id="Group_743" data-name="Group 743" transform="translate(2.041 2.041)">
            <ellipse id="Ellipse_200" data-name="Ellipse 200" cx="3.098" cy="3.098" rx="3.098" ry="3.098" fill="url(#linear-gradient-4)"/>
          </g>
          <g id="Group_744" data-name="Group 744" transform="translate(4.828 3.188)">
            <path id="Path_646" data-name="Path 646" d="M143.35,229.858a1.148,1.148,0,1,1-1.147-1.148A1.147,1.147,0,0,1,143.35,229.858Z" transform="translate(-141.055 -228.71)" fill="#eefdff"/>
          </g>
          <g id="Group_745" data-name="Group 745" transform="translate(4.223 7.057)">
            <ellipse id="Ellipse_201" data-name="Ellipse 201" cx="0.458" cy="0.458" rx="0.458" ry="0.458" fill="#eefdff"/>
          </g>
          <g id="Group_746" data-name="Group 746" transform="translate(3.087 6.599)">
            <path id="Path_647" data-name="Path 647" d="M138.912,234.035a.229.229,0,1,1-.229-.229A.229.229,0,0,1,138.912,234.035Z" transform="translate(-138.454 -233.806)" fill="#eefdff"/>
          </g>
        </g>
        <path id="Path_659" data-name="Path 659" d="M132.449,186.76a1.858,1.858,0,1,1-1.858-1.858A1.858,1.858,0,0,1,132.449,186.76Z" transform="translate(-10464.885 -19033.613)" fill="url(#linear-gradient-6)"/>
        <path id="Path_663" data-name="Path 663" d="M152.072,214.75a2.033,2.033,0,0,1-1.495,1.994c-.761.083-1.368-.694-1.994-1.5s-1.967-2.818-1.43-3.391C147.863,211.1,152.014,212.7,152.072,214.75Z" transform="translate(-10470.935 -19042.463)" fill="#fff"/>
        <ellipse id="Ellipse_203" data-name="Ellipse 203" cx="0.646" cy="0.646" rx="0.646" ry="0.646" transform="translate(-10326.254 -18832.447)" fill="#fff"/>
        <path id="Path_662" data-name="Path 662" d="M151.245,229.189c-.208.146-1.652-2.8-5.53-5.348-1.363-.9-2.708-1.537-2.628-1.722s1.6.162,2.81.725C149.762,224.637,151.491,229.015,151.245,229.189Z" transform="translate(-10469.629 -19045.902)" fill="#fff"/>
        <path id="Path_661" data-name="Path 661" d="M137.616,203.268c-.046.006-.076-.265-.3-.685a3.784,3.784,0,0,0-.226-.363c-.39-.535-1.709-.524-1.813-.523-2.055.017-3.377-.112-3.377-.1s.964-.009,1.671-.023c1.993-.041,3.18-.148,3.689.386a1.669,1.669,0,0,1,.317.509A1.071,1.071,0,0,1,137.616,203.268Z" transform="translate(-10465.931 -19039.113)" fill="#fff"/>
        <path id="Path_657" data-name="Path 657" d="M135.346,243.827a1.049,1.049,0,0,1-.952.919l-6.808.657a1.048,1.048,0,0,1-1.11-.72,4.526,4.526,0,0,1-.147-.651.227.227,0,0,1,.2-.26l8.589-.828a.224.224,0,0,1,.245.213A4.552,4.552,0,0,1,135.346,243.827Z" transform="translate(-10464.088 -19052.807)" fill="#eefdff"/>
        <path id="Path_658" data-name="Path 658" d="M135.434,244.264a4.546,4.546,0,0,1-8.844.938,1.052,1.052,0,0,0,1.082.637l6.81-.655A1.051,1.051,0,0,0,135.434,244.264Z" transform="translate(-10464.177 -19053.242)" fill="#376ad0"/>
      </g>
    </g>
  </svg>`
