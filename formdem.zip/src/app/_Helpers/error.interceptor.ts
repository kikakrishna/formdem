import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AuthenticationService } from '../_Services/authentication.service';
import { Router } from '@angular/router';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
    constructor(private authenticationService: AuthenticationService, 
        private router: Router) { }

    // intercept(
    //     request: HttpRequest<any>,
    //     next: HttpHandler
    //   ): Observable<HttpEvent<any>> {
    //     return next.handle(request).pipe(
    //       catchError((err) => {
    //         if (
    //           [401, 403].includes(err.status) &&
    //           this.authenticationService.currentUserValue
    //         ) {
    //           // auto logout if 401 response returned from api
    //           sessionStorage.clear();
    //         //   this.authenticationService.logout();
    //           location.reload();
    //         }
    
    //         const error = (err && err.error && err.error.message) || err.statusText;
    //         return throwError(error);
    //       })
    //     );
    //   }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(request).pipe(catchError(err => {
            if (err.status === 401 || err.status === 403) {
                console.log(err)
                // auto logout if 401 response returned from api
                localStorage.removeItem('Loggedin-user'); 
                localStorage.clear();
                // this.authService.logout();
                // this.authService.loginRedirect();
                this.router.navigate(['']);   
                // this.adalSvc.logout();
                // location.reload(true);
            }

            const error = err.error.message || err.statusText;
            return throwError(err);
        }))
    }
}