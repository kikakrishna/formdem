import { BrowserModule } from '@angular/platform-browser';
import { APP_INITIALIZER, CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastModule } from 'ng-uikit-pro-standard';
import { JwtInterceptor } from './_Helpers/jwt.interceptor';
import { ErrorInterceptor } from './_Helpers/error.interceptor';
import { AuthGuard } from './_Gaurds/auth.guard';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerModule } from "ngx-spinner";
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { appInitializer } from './_Helpers/app.initializer';
import { AuthenticationService } from './_Services/authentication.service';

import { FooterModule } from './_Components/Layout/footer/footer.module';
import { SidemenuModule } from './_Components/Layout/sidemenu/sidemenu.module';
import { ContentComponent } from './_Components/Layout/content/content.component';

@NgModule({
  declarations: [
    AppComponent,
    ContentComponent,
   

  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    FooterModule,
    SidemenuModule,
    MatSnackBarModule,
    ToastModule.forRoot({ timeOut: 2000, enableHtml: true }),
    RouterModule.forRoot([
      {
        path: '',
        loadChildren: () => import('./_Components/Auth/login/login.module').then(m => m.LoginModule)
      },
      // {
      //   path: '',
      //   component: ContentComponent,
      //   loadChildren: () => import('./_Components/Pages/statistictools/statistictools.module').then(m => m.StatistictoolsModule),
      //   // canActivate: [AuthGuard],
      // },
      {
        path: 'dashboard',
        component: ContentComponent,
        loadChildren: () => import('./_Components/Pages/dashboard/dashboard.module').then(m => m.DashboardModule),
        // canActivate: [AuthGuard],
      },
      {
        path: 'jobstatus',
        component: ContentComponent,
        loadChildren: () => import('./_Components/Pages/job-status/job-status.module').then(m => m.JobStatusModule),
      },
      {
        path: 'singlejob-visualization',
        component: ContentComponent,
        loadChildren: () => import('./_Components/Pages/single-job-visualization/single-job-visualization.module').then(m => m.SingleJobVisualizationModule),
        // canActivate: [AuthGuard],
      },
      {
        path: 'jobcreation',
        component: ContentComponent,
        loadChildren: () => import('./_Components/Pages/jobcreation/jobcreation.module').then(m => m.JobcreationModule),
        // canActivate: [AuthGuard],
      },
      {
        path: 'userlist',
        component: ContentComponent,
        loadChildren: () => import('./_Components/Pages/user-list/user-list.module').then(m => m.UserListModule),
        // canActivate: [AuthGuard],
      },
      {
        path: 'projectlist',
        component: ContentComponent,
        loadChildren: () => import('./_Components/Pages/projectlist/projectlist.module').then(m => m.ProjectlistModule),
      },
      {
        path: 'projectdetails',
        component: ContentComponent,
        loadChildren: () => import('./_Components/Pages/projectdetails/projectdetails.module').then(m => m.ProjectdetailsModule),
        // canActivate: [AuthGuard],
      },
      {
        path: 'projectdetails/:id',
        component: ContentComponent,
        loadChildren: () => import('./_Components/Pages/projectdetails/projectdetails.module').then(m => m.ProjectdetailsModule),
        // canActivate: [AuthGuard],
      },
      {
        path: 'visualization',
        component: ContentComponent,
        loadChildren: () => import('./_Components/Pages/visualization/visualization.module').then(m => m.VisualizationModule),
        // canActivate: [AuthGuard],
      },
      {
        path: 'projectreport',
        component: ContentComponent,
        loadChildren: () => import('./_Components/Pages/projectreport/projectreport.module').then(m => m.ProjectreportModule),
        // canActivate: [AuthGuard],
      },
      // {
      //   path: 'statistictools',
      //   component: ContentComponent,
      //   loadChildren: () => import('./_Components/Pages/statistictools/statistictools.module').then(m => m.StatistictoolsModule),
      //   // canActivate: [AuthGuard],
      // },

    ],
      { anchorScrolling: 'enabled', useHash: true, scrollPositionRestoration: 'enabled' }),
    BrowserAnimationsModule
  ],
  entryComponents: [],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: appInitializer,
      multi: true,
      deps: [AuthenticationService],
    },
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
  ],
  bootstrap: [AppComponent]
})
export class AppModule {

}
