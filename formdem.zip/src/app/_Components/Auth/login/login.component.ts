import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { InteractionStatus, RedirectRequest } from '@azure/msal-browser';
import { Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';
import { Router } from '@angular/router';
import { FormGroup } from '@angular/forms';
import { FormBuilder, Validators, FormControl, FormArray, NgForm } from '@angular/forms';
import { AuthenticationService } from 'src/app/_Services/authentication.service';
import { first } from 'rxjs/operators';
import { ToastService } from 'ng-uikit-pro-standard';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginDisplay = false;
  private readonly _destroying$ = new Subject<void>();
  loading: boolean;

  constructor(public router: Router,
    public _formBuilder: FormBuilder,
    private authenticationService: AuthenticationService,
    private toastrService: ToastService,) { }
  adduserGroup: FormGroup
  ngOnInit(): void {
    this.adduserGroup = this._formBuilder.group({
      email: ['', [Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      password: [''],

    });
  }

  login() {
    console.log("login");
    if (this.adduserGroup.valid) {
      console.log("valid");
      if (this.adduserGroup?.value.email.trim() != "") {

        if (this.adduserGroup?.value.password.trim() != "") {
          this.loading = true
          console.log(this.adduserGroup?.value.email)
          console.log(this.adduserGroup?.value.password)
          let payload: any = {}
          payload = {
            "email": this.adduserGroup?.value.email,
            "password": this.adduserGroup?.value.password
          }
          this.authenticationService.login2(payload)
            .pipe(first())
            .subscribe((res: any) => {
              console.log(res)
              if (!res.error) {
                this.loading = false;
                // this.Chatbot();
                this.router.navigate(['/dashboard']);

                // if (res.responseMessage.firstname === 'admin') {
                //   this.router.navigate(['/dashboard']);
                // }
                // if (res.responseMessage.firstname === '	user') {
                //   this.router.navigate(['/dashboard']);
                // }

              } else {
                // this.loading = false;
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', res.errorMessage, options);
              }
            },
              err => {
                // formDirective.resetForm();
                this.adduserGroup.reset();
                console.log('catch------', err)
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                // if (err?.error.Username) {
                this.toastrService.warning('', err?.errorMessage, options);
                // }
                // if (err?.error.Password) {
                //   this.toastrService.warning('', err?.error.Password[0], options);
                // }
              });

        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "Enter password", options);
        }
      } else {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "Enter user name", options);
      }
    }



  }

  logout() {

  }

  setLoginDisplay() {


  }

  ngOnDestroy(): void {

  }

}