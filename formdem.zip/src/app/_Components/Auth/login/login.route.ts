import { RouterModule } from '@angular/router';
import { LoginComponent } from './login.component';
export const LoginRoute: RouterModule[] = [
    {
        path: '',
        component: LoginComponent
    }
]