import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormBuilder, Validators } from '@angular/forms';
import { AdminService } from 'src/app/_Services/admin.sevice';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';
import { Router } from '@angular/router';
import { MatDialogRef } from '@angular/material/dialog';


@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent implements OnInit {
  email: any;
  loading: boolean;
  minlen: any = sessionStorage.getItem('minlen');
  maxlen: any = sessionStorage.getItem('maxlen');
  roletype: any;
  User: any;

  constructor(public _formBuilder: FormBuilder, private toastrService: ToastService,
    private _AdminService: AdminService,  private router: Router,private dialogRef: MatDialogRef<AdduserComponent>) { }
  adduserGroup:FormGroup;
  submit: boolean;
  ngOnInit(): void {
    this.adduserGroup = this._formBuilder.group({
      firstname:['', [Validators.required,Validators.pattern('^[a-zA-Z ]*$')]],
      lastname: ['', [Validators.required,Validators.pattern('^[a-zA-Z ]*$')]],
      email: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      phonenumber: ['', [Validators.required, Validators.pattern("^[0-9]{10,12}$")]],
      password:  ['', [Validators.required, Validators.pattern('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{6,}$')]],
      User : ['', [Validators.required]]
    });
   this.getroletype()
   this.adduserGroup.get('User').setValue(1);
  }
  getroletype() {
    this._AdminService.getroletype()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res);
          this.User = res.responseMessage
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }

  formsubmit() {
    console.log("submit")
    if (this.adduserGroup?.value.email.trim() == '' || this.adduserGroup?.value.email.trim() == null ||
    this.adduserGroup?.value.password.trim() == '' || this.adduserGroup?.value.password.trim() == null ||
    this.adduserGroup?.value.phonenumber.trim() == '' || this.adduserGroup?.value.phonenumber.trim() == null ||
    this.adduserGroup?.value.firstname.trim() == '' || this.adduserGroup?.value.firstname.trim() == null ||
    this.adduserGroup?.value.lastname.trim() == '' || this.adduserGroup?.value.lastname.trim() == null 
  ) {
    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    this.toastrService.warning('', 'Please fill the mandatory fields', options);
    this.loading = false;
    return;
  }
  else if(this.adduserGroup?.controls?.password?.invalid || this.adduserGroup?.controls?.phonenumber?.invalid
  || this.adduserGroup?.controls?.email?.invalid || this.adduserGroup?.controls?.firstname?.invalid || this.adduserGroup?.controls?.lastname?.invalid){
    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    this.toastrService.warning('', 'Please enter valid details', options);
    this.loading = false;
    return;
  }
 
  else {
  // if (this.submit == true) {
    console.log("submitform");
    let payload = {
      "email": this.adduserGroup.value.email,
      "phonenumber": this.adduserGroup.value.phonenumber,
      "password": this.adduserGroup.value.password,
      "lastname": this.adduserGroup.value.lastname,
      "firstname": this.adduserGroup.value.firstname,
      "role_id" : this.adduserGroup.value.User,
    }
    console.log(payload);

    this._AdminService.createuser(payload)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.error) {
          console.log(res);
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.responseMessage, options);
          // this.router.navigate(['/userlist']);
          this.dialogRef.close({ data: "yes" });
          this.adduserGroup.reset();
          
        }
        else {
          console.log(res.errorMessage)
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage,options);
        }
      },
        // err => {
        //   //  this.dialogRef.close({ data: err });
        //   const options = { opacity: 1, timeOut: 2000};
        //   this.toastrService.warning('', err?.error,options);
        // }
        );
  }}
  cancelclick(){
    this.dialogRef.close({ data: "no" });

  }
}
// }
