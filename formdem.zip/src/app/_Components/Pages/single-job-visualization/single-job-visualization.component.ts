import { Component, OnInit } from '@angular/core';

export interface PeriodicElement {
  name: string;
  ingredient: string;
  fraction: string;
  activity: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
  {ingredient: "API Maleate", name: '50', fraction:"0.2", activity: '0.86'},
  {ingredient: "Mannitol", name: '50', fraction: "0.2", activity: '0.86'},
  {ingredient: "Starch", name: '50', fraction: "0.2", activity: ''},
  {ingredient: "Pre gelatinized starch", name: '50', fraction: "0.2", activity: ''},
  {ingredient: "YY", name: '', fraction:"0.2", activity: '0.86'},
  {ingredient: "Sodium Stearyl Fumarate", name: '', fraction:"", activity: ''},
  {ingredient: "VV", name: '50', fraction:"0.2", activity: ''},
  {ingredient: "XX", name: '', fraction: "0.2", activity: ''},
  {ingredient: "NN", name: '50', fraction: "0.2", activity: '0.86'},
  {ingredient: "Weight of Core Tablet", name: '', fraction: "", activity: ''},
];
@Component({
  selector: 'app-single-job-visualization',
  templateUrl: './single-job-visualization.component.html',
  styleUrls: ['./single-job-visualization.component.css']
})
export class SingleJobVisualizationComponent implements OnInit {
  displayedColumns: string[] = ['ingredient', 'name', 'fraction', 'activity'];
  dataSource = ELEMENT_DATA;
  constructor() { }
  loading: boolean;
  ngOnInit(): void {
  }

}
