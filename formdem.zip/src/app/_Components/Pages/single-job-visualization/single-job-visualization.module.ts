import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SingleJobVisualizationComponent } from './single-job-visualization.component';
import { SingleJobVisualizationRoutes } from './single-job-visualization.routes';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import {MatSelectModule} from '@angular/material/select';
 import {MatRadioModule} from '@angular/material/radio';
 import { MatFormFieldModule } from '@angular/material/form-field';
import {  MatTableModule } from '@angular/material/table';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';

@NgModule({
  declarations: [SingleJobVisualizationComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(SingleJobVisualizationRoutes),
    MatCardModule,
    MatButtonModule,
    MatSelectModule,
     MatRadioModule,
     MatFormFieldModule,
     MatTableModule,
     MatMenuModule,
     MatIconModule
     
  ]
  
})
export class SingleJobVisualizationModule { }
