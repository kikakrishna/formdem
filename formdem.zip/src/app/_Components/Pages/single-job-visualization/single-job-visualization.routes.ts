import { RouterModule } from "@angular/router";
import { SingleJobVisualizationComponent } from "./single-job-visualization.component";
export const SingleJobVisualizationRoutes: RouterModule [] = [
    {
        path: '',
        component: SingleJobVisualizationComponent
    }
]