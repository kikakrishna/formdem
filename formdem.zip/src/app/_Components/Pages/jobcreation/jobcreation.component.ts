import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormBuilder, Validators, FormControl, FormArray, NgForm } from '@angular/forms';
import { Observable, ReplaySubject, Subject } from 'rxjs';
import { ToastService } from 'ng-uikit-pro-standard';
import { AdminService } from 'src/app/_Services/admin.sevice';
import { first, retry, take, takeUntil, map, startWith } from 'rxjs/operators';
import { AuthenticationService } from 'src/app/_Services/authentication.service';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { JobcreationSavemoleculesComponent } from '../jobcreation-savemolecules/jobcreation-savemolecules.component';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-jobcreation',
  templateUrl: './jobcreation.component.html',
  styleUrls: ['./jobcreation.component.css']
})
export class JobcreationComponent implements OnInit {
  createprojectGroup: FormGroup;
  addForm: FormGroup;
  addFormapi: FormGroup;
  addFormproto: FormGroup;
  rows: FormArray;
  rowsapi: FormArray;
  rowsapiproto: FormArray;
  project: any = [];
  addformjson: FormArray;
  itemForm: FormGroup;
  apiinformationForm: FormGroup;
  PrototypeJobSubmission: FormGroup;
  sample: FormGroup;
  arraynumbers: any;
  containers = [];
  prototyperadiobtn: any;
  divNameMap = {};
  divNameMappppp = {};
  filteredOptions: Observable<any[]>;
  filteredOptionssidenav: Observable<any[]>;
  molearray: Observable<any[]>;
  selectedOption: any;
  jsondata: any = [];
  jsondatasubmission: any = [];
  moleculediv: Boolean = true;
  multiplediv: Boolean;
  uploaddiv: Boolean;
  singlediv: Boolean = true;
  prototype: any;
  firstname: string;
  lastname: string;
  excipinentname: any;
  todaydate = new Date();
  // payloaddate = new Date();
  loading: boolean;

  curr_hour: any;
  curr_min: any;
  curr_sec: any;
  paloaddate: any;
  currentdate: any;
  excippinentaddtable: boolean = false;
  constructor(public _formBuilder: FormBuilder,
    private fbmolecule: FormBuilder,
    private fbapiinformation: FormBuilder,
    private fbapiinform: FormBuilder,
    private fbprototype: FormBuilder,
    private fbsample: FormBuilder,
    private toastrService: ToastService,
    private _AdminService: AdminService,
    public authenticationService: AuthenticationService,
    private router: Router,
    // public dialogRef: MatDialogRef<JobcreationSavemoleculesComponent>,
    public dialog: MatDialog,
  ) {
    this.firstname = sessionStorage.getItem("firstname");
    this.lastname = sessionStorage.getItem("lastname");
    this.addForm = this.fbmolecule.group({
      items: [true, Validators.required],
      items_value: ['no', Validators.required]
    });
    this.addFormapi = this.fbapiinform.group({
      items: [true, Validators.required],
      items_value: ['no', Validators.required]
    });
    this.addFormproto = this.fbprototype.group({
      items: [true, Validators.required],
      items_value: ['no', Validators.required]
    });

    this.rows = this.fbmolecule.array([]);
    this.rowsapi = this.fbapiinform.array([]);
    this.rowsapiproto = this.fbprototype.array([]);

  }

  ngOnInit(): void {

    this.curr_hour = this.todaydate.getHours();
    this.curr_min = this.todaydate.getMinutes();
    // this.paloaddate = this.todaydate.toUTCString()
    this.paloaddate = this.todaydate.toISOString();
    this.paloaddate = moment(this.todaydate).format();
    var date = moment(this.todaydate).subtract(10, 'days').calendar();
    console.log(date);


    this.curr_sec = this.todaydate.getSeconds();

    this.currentdate = moment(this.todaydate).format('DD-MM-YYYY');
    // const time = moment(this.todaydate).format('HH-MM-SS');
    console.log(this.paloaddate);
    // console.log(this.paloaddate.toISOString());
    // const hour = this.paloaddate.getUTCHours();
    // const minute = this.paloaddate.getUTCMinutes();
    // console.log("time-------------", hour + minute);

    this.createprojectGroup = this._formBuilder.group({
      Project: ['', Validators.required],
      Prototype: ['', Validators.required],
      Jobdescription: ['', Validators.required],
    });

    this.PrototypeJobSubmission = this._formBuilder.group({
      jobname: ['', Validators.required,],
      // temperature: ['', Validators.required], Validators.pattern('^[0-9]*$')
      temperature: ['', [Validators.required, Validators.pattern(/^[0-9]+([.][0-9]{0,2})?$/)]],
      // temperature: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],


      RH: ['', Validators.required],
    });

    this.sample = this.fbsample.group({
      samplearray: this.fbsample.array([])
    });



    this.apiinformationForm = this.fbapiinformation.group({
      filters: this.fbapiinformation.array([])
    });



    // this.jsondatasubmission = [{
    //   "checked": true,
    //   "name": "Single Prototype Job Submission",
    //   "value": "SP",
    // },
    // {
    //   "checked": false,
    //   "name": "Multiple Prototype Job Submission",
    //   "value": "MP",
    // }]

    
    
    this.addForm.addControl('rows', this.rows);
    this.addFormapi.addControl('rowsapi', this.rowsapi);
    this.addFormproto.addControl('rowsapiproto', this.rowsapiproto);

    // this.onAddRow()
    // this.onAddRow()
    console.log(this.rows.value);

    this.onAddRowAPI()
    // this.onAddRowAPI()
    this.onAddRowproto()
    // this.onAddRowproto()

    this.seedFiltersFormArray()

    this.add();

    // form array call
    this.addsample()
    // prototype radiobtn 
    this.prototyperadiobtn = "SP"

    // project API
    this.getproject();
    // proto API
    this.getproto();

    this.getsubmission();
    this.getdata();
  }

  getsubmission = async () => {
    this.jsondatasubmission = await [{
      "checked": true,
      "name": "Single Prototype Job Submission",
      "value": "SP",
    },
    {
      "checked": false,
      "name": "Multiple Prototype Job Submission",
      "value": "MP",
    }]
  }
  getdata = async () => {
    this.jsondata = await [{
      "checked": true,
      "name": "Single Molecule Smiles",
      "value": 1,
    },
    {
      "checked": false,
      "name": "File Upload SDF / Mol2",
      "value": 2,
    }]

    this.selectedOption = this.jsondata[0].value;

  }

  getproto() {
    this.loading = true
    this._AdminService.getprototye()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false
          console.log(res);
          this.prototype = res.responseMessage

        }
        else {
          this.loading = false
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          // setTimeout(() => {
          //   this.toastrService.clear(),2000
          // }, 2000);

        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }
  getproject() {
    this.loading = true
    this._AdminService.getproject()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false
          console.log(res);
          this.project = res.responseMessage

        }
        else {
          this.loading = false
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          // setTimeout(() => {
          //   this.toastrService.clear(),2000
          // }, 2000);

        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }

  changeType(ele) {
    console.log(ele.value);
    if (ele.value == 1) {
      this.moleculediv = true
      this.uploaddiv = false
    } else {
      this.uploaddiv = true
      this.moleculediv = false

    }

  }

  get addDynamicRow() {
    return this.addForm.get('rows') as FormArray;
  }

  onAddRow() {
    this.excippinentaddtable = true;
    this.disablefield = true;
    this.rows.push(this.createItemFormGroup());
    console.log(this.rows.value)
    if (this.rows.value.length > 0) {
      // this.savemoleculesbtn = false;
      this.savemoleculesbtnhide = true;
    }
  }


  createItemFormGroup(): FormGroup {
    return this.fbmolecule.group({
      excipientname: null,
      smiles: null,
      charge: null,
      isdelete: true,
      readonly: false
    });
  }

  onRemoveRow(rowIndex: number, elerow) {

    console.log(elerow);

    this.rows.removeAt(rowIndex);
    console.log(this.rows.value);



    console.log(this.rows.value.length);


    if (this.rows.value.length == 0) {
      // this.savemoleculesbtn = true;
      this.excippinentaddtable = false;
      this.savemoleculesbtnhide = false;

    }


  }



  // API-section start--------------------------------------------------------
  onAddRowAPI() {
    this.rowsapi.push(this.createItemFormGroupApi());
    console.log(this.rowsapi.value)

  }

  createItemFormGroupApi(): FormGroup {
    return this.fbapiinform.group({
      Name: null,
      Temp: null,
      Title: null
    });
  }

  onRemoveRowAPI(rowIndex: number) {
    this.rowsapi.removeAt(rowIndex);
  }


  get addDynamicRowapi() {
    return this.addFormapi.get('rowsapi') as FormArray;
  }


  // apiinformationfor-add------------------------
  addFilterToFiltersFormArray() {
    this.filtersFormArray.push(this.createFilterGroupapi());
    console.log(this.filtersFormArray);

  }

  seedFiltersFormArray() {
    console.log("seedFiltersFormArray");

    const formGroup = this.createFilterGroupapi();
    formGroup.addControl('value', this.getFormControl());


  }

  createFilterGroupapi() {
    return this.fbapiinformation.group({
      Apiname: null,
      Mp: null,
      Hfus: null,

    });
  }

  get filtersFormArray() {
    return (<FormArray>this.apiinformationForm.get('filters'));
  }

  removeFilterFromFiltersFormArray(index) {
    this.filtersFormArray.removeAt(index);
  }

  getFormControl() {
    return this.fbapiinformation.control(null);
  }


  // ---------------------prototype submission
  changeTypesubmission(ele) {
    console.log(ele.value);
    this.prototyperadiobtn = ele.value
    if (ele.value == "SP") {
      this.singlediv = true
      this.multiplediv = false
    } else {
      this.multiplediv = true
      this.singlediv = false

    }
  }

  // disablefield :boolean = true;
  onAddRowproto() {
    console.log(this.addFormproto);
    // this.excipinentname = ""
    console.log(this.rowsapiproto.value)


    this.rowsapiproto.push(this.createItemFormGroupproto());
    // setTimeout(() => {

    // }, 100);

    console.log(this.addFormproto.value.rowsapiproto);
    this.filteredOptions = null;


  }

  createItemFormGroupproto(): FormGroup {
    return this.fbprototype.group({
      ExcipientName: "",
      Wtfraction: "",
      ExcipientId: "",
    });
  }

  onRemoveRowproto(rowIndex: number) {
    this.rowsapiproto.removeAt(rowIndex);

  }


  get addDynamicRowproto() {
    return this.addFormproto.get('rowsapiproto') as FormArray;
  }



  drugArray: any = [];
  // molearray: any = [];
  patientControl = new FormControl();


  getDropdown(event) {
    console.log(event.target.value);
    console.log(this.addFormproto.value.rowsapiproto);
    for (let i of this.addFormproto.value.rowsapiproto) {
      // if (i.ExcipientName.trim() != "") {
      console.log(true);
      if (event.target.value.length >= 2) {
        this.loading = true
        this._AdminService.getmoleculekeyup(event.target.value)
          .pipe(first())
          .subscribe((res: any) => {
            if (!res.isError) {
              this.loading = false
              console.log(res);
              // this.project = res.responseMessage
              console.log(this.addFormproto.value.rowsapiproto);

              this.drugArray = res.responseMessage;
              console.log(this.drugArray);
              this.molearray = res.responseMessage
              this.filteredOptions = this.patientControl.valueChanges
                .pipe(
                  startWith(''),
                  map(value => this._filter(value)),

                );
              console.log(this.filteredOptions)
            }
            else {
              this.loading = false
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', res.errorMessage, options);
              // setTimeout(() => {
              //   this.toastrService.clear(),2000
              // }, 2000);

            }
          },
            err => {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              console.log(err);

            });

      }
      // } else {
      //   console.log("false");
      //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      //   this.toastrService.warning('', "ExcipientName should not be empty", options);
      // }
    }



    if (event.target.value.length == 0) {
      this.filteredOptions = null;
    }

  }

  private _filter(value: string): string[] {
    const filterValue = value;
    console.log(filterValue);

    if (this.drugArray) {
      return this.drugArray.filter(option => option.excipientname.toLowerCase().includes(filterValue));
    }
  }

  excipinetidarray: any = [];
  onSelection(event, i) {
    // this.addFormproto.value.rowsapiproto[i].ExcipientName = event.option.value.excipientname;
    console.log(event);
    console.log(this.addFormproto.value.rowsapiproto);

    console.log(this.addFormproto.value.rowsapiproto[i]);

    this.addFormproto.value.rowsapiproto.forEach((data, index) => {
      if (i = this.addFormproto.value.rowsapiproto[index]) {
        const myForm = (<FormArray>this.addFormproto.get("rowsapiproto")).at(index);
        // console.log(myForm);

        myForm.patchValue({
          ExcipientId: event.option.value.excipient_id,
          // ExcipientId: event.option.value.excipient_id,
          // ExcipientName: event.option.value.excipientname
        })
      }
    });
    // this.excipinentname = event.option.value.excipientname
    // this.addFormproto.value.rowsapiproto[i].value.ExcipientName = event.option.value.excipientname;

    this.filteredOptions = null;

  }

  displayFn(user?: any): string | undefined {
    console.log(user);
    return user ? user.excipientname : undefined;
  }
  projectID: any;
  projectcode: any;

  changeslectproject(event) {
    console.log(event);
    this.projectID = event.value.project_id
    this.projectcode = event.value.projectcode
  }
  payloadcontent: boolean = false;
  projectgrouppayload: any;
  submit: boolean;
  checkexcipinentid: boolean;
  // wtfractionvalidmsg: any;
  wtfractvalidsec: boolean = false;
  wtfracempty: boolean;
  sumvalue: any;
  sampleexcip: boolean;
  formsubmit() {
    console.log(this.addFormproto.value.rowsapiproto);

    var mainrowproto = []
    var arraycheckexcip = []
    for (var i = 0; i < this.addFormproto.value.rowsapiproto.length; i++) {
      console.log(this.addFormproto.value.rowsapiproto[i]);


      let json = {
        "Excipicientid": this.addFormproto.value.rowsapiproto[i].ExcipientName.excipient_id,
        "weightfraction": this.addFormproto.value.rowsapiproto[i].Wtfraction
      }

      mainrowproto.push(json)
    }


    console.log(mainrowproto);

    // var temp = mainrowproto.filter(word => word.Excipicientid == undefined);
    // console.log(temp);

    console.log(this.projectcode + "_" + this.prototyperadiobtn + "_" + this.PrototypeJobSubmission.value.jobname + "_" + this.PrototypeJobSubmission.value.temperature + "C" + "_" + this.PrototypeJobSubmission.value.RH + "RH");
    this.projectgrouppayload = this.projectcode + "_" + this.prototyperadiobtn + "_" + this.PrototypeJobSubmission.value.jobname + "_" + this.PrototypeJobSubmission.value.temperature + "C" + "_" + this.PrototypeJobSubmission.value.RH + "RH";



    if (this.createprojectGroup.valid && this.createprojectGroup.value.Jobdescription.trim() != "") {
      // prototype section validation
      this.wtfractvalidsec = false;
      if (this.PrototypeJobSubmission.valid && this.PrototypeJobSubmission.value.jobname.trim() != ""
        && this.PrototypeJobSubmission.value.temperature.trim() != "" && this.PrototypeJobSubmission.value.RH.trim() != "") {
        console.log("validation");
        // prototype radiobtn 


        if (this.prototyperadiobtn == "SP") {
          if (this.addFormproto.value.rowsapiproto.length != 0) {

            this.wtfractvalidsec = false;
            var numbers = this.addFormproto.value.rowsapiproto
            this.arraynumbers = []

            console.log(numbers);


            var isexcipinent: boolean;
            var validarrayexcipinent = numbers.every(x => x.ExcipientName != "")
            console.log(validarrayexcipinent);

            if (validarrayexcipinent == true) {
              // for (let x of numbers) {
              // if (x.ExcipientName != "") {
              isexcipinent = true

              var validarraywtfraction = mainrowproto.every(x => x.weightfraction.trim() != "")
              console.log(validarraywtfraction);

              // } else {
              //   isexcipinent = false
              //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              //   this.toastrService.warning('', "Excipient Name should not be empty", options);
              // }

              // }


              // if (isexcipinent == true) {
              if (validarraywtfraction == true) {
                this.wtfracempty = true
                for (let x of numbers) {

                  // if (x.Wtfraction.trim() != "") {

                  this.arraynumbers.push(parseFloat(x.Wtfraction))



                }
              } else {
                this.wtfracempty = false
              }
            } else {
              this.wtfracempty = false
            }

            // }


            if (validarraywtfraction == false) {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', "Wtfraction should not be empty", options);
            }
            // if (this.wtfracempty == false) {
            //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            //   this.toastrService.warning('', "Wtfraction should not be empty", options);
            // }
            if (validarrayexcipinent == false) {
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', "Excipient Name should not be empty", options);
            }
            if (this.wtfracempty == true) {
              console.log(this.arraynumbers);

              var sum = 0;
              // let total = this.arraynumbers.reduce(function (curr, prev) { return curr + prev; });

              // console.log(total);
              this.arraynumbers.forEach(x => {
                if (x != null && x != "NaN") {
                  sum += x;
                }
              });
              console.log(sum);

              // console.log(sum.toFixed());
              this.sumvalue = sum.toFixed()
              console.log("sumvalue--------" + this.sumvalue);
              if (sum == 1) {

                this.wtfractvalidsec = false;
                // for (let i of this.rowsapiproto.value) {
                //   if (i.ExcipientName != "") {


                //   } else {
                //     this.payloadcontent = false;

                //     const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                //     this.toastrService.warning('', "Excipient name should not be empty ", options);
                //   }
                // }
                var temp = mainrowproto.filter(word => word.Excipicientid == undefined);

                var arraycheckexcip = []
                for (var i = 0; i < this.addFormproto.value.rowsapiproto.length; i++) {
                  console.log(this.addFormproto.value.rowsapiproto[i]);

                  if (this.addFormproto.value.rowsapiproto[i].ExcipientName.excipient_id == undefined) {
                    let json = {
                      "ExcipientName": this.addFormproto.value.rowsapiproto[i].ExcipientName

                    }

                    arraycheckexcip.push(json)
                  }

                }
                var teporary = []
                for (let i of arraycheckexcip) {
                  teporary.push(i.ExcipientName)
                }
                console.log(arraycheckexcip);

                var validmsgexcipnames = teporary.toString()
                console.log(teporary);

                // var tempvalidexciname = this.addFormproto.value.rowsapiproto.filter(word => word.ExcipientName.excipient_id != "");
                // console.log(tempvalidexciname);

                console.log(temp)
                if (temp.length == 0) {
                  this.checkexcipinentid = true
                } else {
                  this.checkexcipinentid = false

                }
                if (this.checkexcipinentid == true) {
                  this.submit = true;
                  this.checkexcipinentid = false
                  this.payloadcontent = true;
                } else {
                  this.submit = false;
                  this.payloadcontent = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', validmsgexcipnames + " is invalid excipient name", options);

                }
                if (this.submit == true) {


                  if (this.temparray == 0) {
                    console.log("no need DMfiles");

                    console.log(this.rows.value);
                    console.log("submitform");
                    let payload = {
                      // "Project_id": this.createprojectGroup.value.Project,
                      "Project_id": this.projectID,
                      "Prototypeid": this.createprojectGroup.value.Prototype,
                      // "Prototypeid": this.createprojectGroup.value.Prototype,
                      "JobDescription": this.createprojectGroup.value.Jobdescription,
                      // "Jobname": this.PrototypeJobSubmission.value.jobname,
                      "Jobname": this.projectgrouppayload,
                      // "StartDateTime": "2023-04-29T18:00:00",
                      "StartDateTime": this.paloaddate,
                      "Temp": parseFloat(this.PrototypeJobSubmission.value.temperature),
                      "RH": this.PrototypeJobSubmission.value.RH,
                      "Excipicient": mainrowproto,


                    }
                    console.log(payload);
                    this.loading = true
                    this._AdminService.createjob(payload)
                      .pipe(first())
                      .subscribe((res: any) => {
                        if (!res.error) {
                          this.loading = false
                          console.log(res);
                          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                          this.toastrService.success('', res.responseMessage, options);
                          this.router.navigate(['/jobstatus']);
                        }
                        else {
                          this.loading = false
                          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                          this.toastrService.warning('', res.errorMessage, options);


                        }
                      },
                        err => {
                          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                          console.log(err);

                        });
                  } else {
                    console.log(" need DMfiles");

                    // if (this.temparray.length > 0) {
                    console.log("success");
                    const temp = this.temparray.flat()
                    var samplearray = []
                    for (let xaxis of temp) {

                      let json = {
                        "molecule_name": xaxis.excipientname,
                        "smiles_notation": xaxis.smiles,
                        "charge": xaxis.charge
                      }
                      samplearray.push(json)
                    }
                    let payloaddddd = {
                      // "Project_id": this.createprojectGroup.value.Project,
                      "Project_id": this.projectID,

                      "Prototypeid": this.createprojectGroup.value.Prototype,
                      // "Prototypeid": this.createprojectGroup.value.Prototype,
                      "JobDescription": this.createprojectGroup.value.Jobdescription,
                      // "Jobname": this.PrototypeJobSubmission.value.jobname,
                      "Jobname": this.projectgrouppayload,
                      // "StartDateTime": "2023-04-29T18:00:00",
                      "StartDateTime": this.paloaddate,
                      "Temp": parseFloat(this.PrototypeJobSubmission.value.temperature),
                      "RH": this.PrototypeJobSubmission.value.RH,
                      "Excipicient": mainrowproto,
                      "DEMfiles_list": samplearray

                    }
                    console.log(payloaddddd);
                    this.loading = true
                    this._AdminService.createjob(payloaddddd)
                      .pipe(first())
                      .subscribe((res: any) => {
                        if (!res.error) {
                          this.loading = false
                          console.log(res);
                          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                          this.toastrService.success('', res.responseMessage, options);
                          this.router.navigate(['/jobstatus']);
                        }
                        else {
                          this.loading = false
                          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                          this.toastrService.warning('', res.errorMessage, options);


                        }
                      },
                        err => {
                          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                          console.log(err);

                        });

                  }

                }
              } else {
                this.payloadcontent = false;
                this.wtfractvalidsec = true;
                // this.wtfractionvalidmsg = "Sum of Wt.fraction must be equal to one"
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', "Sum of Wt.fraction must be equal to one", options);
              }
            }



          } else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', "Excipient values was empty", options);
          }

        }


      } else {
        this.payloadcontent = false;
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "Please enter prototype job submission fields", options);
      }
    }
    else {
      this.payloadcontent = false;
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please enter project fields", options);
    }
  }


  // ----------------------------------------------------------------------

  sampleformarray(): FormArray {
    return this.sample.get('samplearray') as FormArray;
  }

  newEmployee(): FormGroup {
    return this.fbsample.group({
      ex1: '',
      ex2: '',
      ex3: '',
      skills: this.fbsample.array([])
    });
  }

  addsample() {
    this.sampleformarray().push(this.newEmployee());
    console.log(this.sample.value.samplearray[0].skills);

    setTimeout(() => {
      this.addEmployeeSkill(0)

    }, 1000);

    // if (this.sample.value.samplearray[0].skills.length == 0) {
    //   console.log("lengtrh --------------"+this.sample.value.samplearray[0].skills.lenght);

    //   this.addEmployeeSkill(0)

    // }
  }

  tableloop: any;
  add() {
    this.containers.push(this.containers.length);

    console.log(this.containers);
  }

  // nested array---------------------------------------------------
  employeeSkills(empIndex: number): FormArray {
    console.log(empIndex);

    return this.sampleformarray()
      .at(empIndex)
      .get('skills') as FormArray;
  }

  // newSkill(): FormGroup {
  //   return this.fbsample.group({
  //     skill: '',
  //     exp: ''
  //   });
  // }

  addEmployeeSkill(empIndex: number) {
    this.employeeSkills(empIndex).push(this.createsamplegroup());
    console.log(this.sample.value);

  }

  removeEmployeeSkill(empIndex: number, skillIndex: number) {
    this.employeeSkills(empIndex).removeAt(skillIndex);
  }

  createsamplegroup(): FormGroup {
    return this.fbsample.group({
      Name: null,
      temp: null,
      value: null
    });
  }


  logout() {
    this.authenticationService.logout();
    this.router.navigate(['']);
  }
  savemoleculesbtn: boolean = true;
  savemoleculesbtnhide: boolean = false;
  issavebtnvalid: boolean = false;
  disablefield: boolean = true;
  isReadonly = false;
  temparray: any = [];
  moleculedeleicon: boolean = true;
  storagearray: any = [];


  savemolecules(rowIndex) {

    var temparraysample = []
    for (let z of this.rows.value) {

      if (z.isdelete == true) {
        var rowsvaluelooped = {
          "excipientname": z.excipientname,
          "smiles": z.smiles,
          "charge": z.charge
        }

        temparraysample.push(rowsvaluelooped)
      }

      // z.isdelete = false
      // z.readonly = true
      if (z.excipientname != null) {
        if (z.excipientname.trim() != "") {
          if (z.smiles != null) {

            if (z.smiles.trim() != "") {
              if (z.charge != null) {
                if (z.charge.trim() != "") {
                  this.issavebtnvalid = true;

                } else {
                  this.issavebtnvalid = false;
                  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                  this.toastrService.warning('', "Charge should not be empty", options);
                }


              } else {
                const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                this.toastrService.warning('', "Charge should not be empty", options);
                console.log("array has NULL charge");
                this.issavebtnvalid = false;
              }

            } else {
              this.issavebtnvalid = false;
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', "Smiles should not be empty", options);
            }

          } else {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', "Smiles should not be empty", options);
            console.log("array has NULL smiles");
            this.issavebtnvalid = false;
          }
        } else {
          this.issavebtnvalid = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "Molecule name should not be empty", options);
        }


      } else {
        console.log("array has NULL Molecule name");
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "Molecule name should not be empty", options);
        this.issavebtnvalid = false;

      }

    }
    console.log(temparraysample);
    console.log(this.rows.value);


    if (this.issavebtnvalid == true) {

      if (temparraysample.length != 0) {
        const dialogRef = this.dialog.open(JobcreationSavemoleculesComponent, {
          width: '100%',
          data: this.rows.value,
          panelClass: 'savemolecules',
        });
        dialogRef.afterClosed().subscribe(result => {
          if (result) {
            if (result.data) {
              console.log(result.data)

              var jsonpaylod = {
                "DMfiles": temparraysample
              }

              console.log(jsonpaylod);

              this.loading = true
              this._AdminService.savemolecules(jsonpaylod)
                .pipe(first())
                .subscribe((res: any) => {
                  if (!res.error) {
                    this.loading = false
                    this.moleculedeleicon = false;
                    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                    this.toastrService.success('', res.responseMessage, options);
                    for (let y of this.rows.value) {
                      y.isdelete = false
                      y.readonly = true
                    }
                    console.log(this.rows.value);

                    this.temparray.push(temparraysample)
                    console.log("temp-------------" + JSON.stringify(this.temparray));
                    console.log("temp---flat----------" + JSON.stringify(this.temparray.flat()));

                  }
                  else {
                    this.loading = false
                    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                    this.toastrService.warning('', res.errorMessage, options);

                  }
                },
                  err => {
                    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
                    console.log(err);

                  });


            } else {
              this.loading = false
              const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
              this.toastrService.warning('', result.data.errorMessage, options);
            }
          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err.error, options);
          });
      } else {
        const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
        this.toastrService.warning('', "Click add to add molecules", options);
      }


    }
    // else {
    //   const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    //   this.toastrService.warning('', " Enter valid Excipinent name, smiles and charge", options);
    // }


  }
}
