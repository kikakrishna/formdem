
import { Component, Inject, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { first, map, startWith } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
// import { MatChipInputEvent} from '@angular/material/chips';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatChipInputEvent } from '@angular/material/chips';
import { MatAutocompleteSelectedEvent, MatAutocomplete, MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import { AdminService } from 'src/app/_Services/admin.sevice';
import { ToastService } from 'ng-uikit-pro-standard';

export interface Fruit {
  name: string;
}

@Component({
  selector: 'app-assignuser',
  templateUrl: './assignuser.component.html',
  styleUrls: ['./assignuser.component.css']
})
export class AssignuserComponent implements OnInit {
  emailform: FormGroup;
  loading: boolean = false;
  studid: any;
  patid: any;

  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = false;
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];
  names: any = [];
  // @Input() emails: string[] = [];
  selectemail = new FormControl();
  @ViewChild('chipdata') chipdata: ElementRef;

  // fruitCtrl = new FormControl('');
  filteredNames: Observable<string[]>;
  allEmails: any[] = [];
  // allEmails: any = [];
  // @ViewChild('fruitInput') fruitInput: ElementRef<HTMLInputElement>;
  @ViewChild('auto', { static: false }) matAutocomplete: MatAutocomplete;
  @ViewChild(MatAutocompleteTrigger) autocomplete: MatAutocompleteTrigger;
  private options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  selectedEmail: any = []
  InputValue: any;
  public onBackspaceKeydown(event) { event.stopImmediatePropagation(); }
  constructor(private formBuilder: FormBuilder,
    private dialogRef: MatDialogRef<AssignuserComponent>, @Inject(MAT_DIALOG_DATA) public data: any,
    private http: HttpClient,
    private toastrService: ToastService,
    private _AdminService: AdminService,
  ) {
    this.filteredNames = this.selectemail.valueChanges.pipe(
      startWith(null),
      map((email: string | null) => (email ? this._filter(email) : this.allEmails.slice())),

    );
    console.log(this.allEmails)
  }
  private _filter(value: string): string[] {
    const filterValue = value
    return this.allEmails.filter(fruit => fruit.name.toLowerCase().includes(filterValue));
  }
  ngOnInit(): void {
    console.log(this.filteredNames);

    this.emailform = this.formBuilder.group({
      subject: [this.data.subject],
      content: [this.data.body],
      // selectedEmail: new FormControl([], Validators.required)
    });

  }

  onMatChipKeyPress(event) {
    console.log(event);
    
    // event.preventDefault();
 }

  nameInput(event) {
    console.log(event.target.value)
    // event.stopImmediatePropagation();

    if (event.target.value == "") {
      return
    }
    this.allEmails = []
    if (this.selectemail.value == "" || this.selectemail.value == null) {
      this.autocomplete.closePanel();
    }
    this.loading = true
    this._AdminService.getassignuserlist(event.target.value)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if (!res.isError) {
          this.loading = false;
          // this.allEmails = []
          console.log(res.responseMessage);
          for (let i of res.responseMessage) {
            this.allEmails.push(i)

          }
          console.log(this.filteredNames);

        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    // console.log(this.selectemail.value)
    // // Add our fruit  
    // if ((value || '').trim()) {
    //   // this.emails.push(value.trim());
    //   this.names.push({ emailid: value.trim() });
    // }

    // // Reset the input value
    // if (input) {
    //   input.value = '';
    // }

    // this.selectemail.setValue(null);
  }

  remove(fruit: Fruit): void {
    const index = this.names.indexOf(fruit);

    if (index >= 0) {
      this.names.splice(index, 1);
    }
  }
  useridarray: any = [];
  selected(event: MatAutocompleteSelectedEvent): void {
    console.log("selected", event.option.value);
    console.log(this.selectemail.value)
    var temp = []
    temp.push(this.selectemail.value)
    // this.useridarray = []
    // console.log(temp);

    // if (this.useridarray.length != 0) {

    //   for (let i of temp) {
    //     this.useridarray.includes(i.userid)

    //     // this.useridarray.push(i.userid)

    //   }else{

    //   }
    // }
    console.log(this.useridarray);

    for (let i of temp) {
      console.log(ischecked);
      if (this.useridarray.length != 0) {
        console.log(i.userid);
        var ischecked = this.useridarray.includes(i.userid)
        console.log(ischecked);
        if (ischecked == false) {
          this.useridarray.push(i.userid)
          this.names.push({ emailid: event.option.viewValue.trim() });

        } else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', "User already selected", options);
        }
      } else {
        this.useridarray.push(i.userid)
        this.names.push({ emailid: event.option.viewValue.trim() });
      }

    }
    console.log(this.useridarray);

    this.chipdata.nativeElement.value = '';
    this.selectemail.setValue(null);
    // this.allEmails = []
    // this.filteredNames = null
  }

  submit() {
    // console.log(this.emailform);
    // console.log(this.names)
    console.log(this.useridarray);
    console.log(this.data);

    if (this.useridarray.length != 0) {

      let payload = {

        "projectid": this.data,
        "userid": this.useridarray


      }
      this.loading = true
      console.log(payload);

      this._AdminService.assignuser(payload)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res)
          if (!res.isError) {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
            this.dialogRef.close({ data: "yes" });
          }
          else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          });
    } else {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please select user", options);
    }

  }

  cancelclick() {
    this.dialogRef.close({ data: "no" });

  }
}
