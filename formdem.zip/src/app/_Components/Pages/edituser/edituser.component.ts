import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormBuilder, Validators } from '@angular/forms';
import { AdminService } from 'src/app/_Services/admin.sevice';
import { Router } from '@angular/router';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';
import { invalid } from '@angular/compiler/src/render3/view/util';
// import{matdi}

@Component({
  selector: 'app-edituser',
  templateUrl: './edituser.component.html',
  styleUrls: ['./edituser.component.css']
})
export class EdituserComponent implements OnInit {
  User: any;
  loading: boolean;
  userdetails: any;

  constructor(public _formBuilder: FormBuilder, private _AdminService: AdminService,
    private router: Router, private dialogRef: MatDialogRef<EdituserComponent>, private toastrService: ToastService,
    @Inject(MAT_DIALOG_DATA) public data: any) { }
  edituserGroup: FormGroup
  ngOnInit(): void {
    this.edituserGroup = this._formBuilder.group({
      firstname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      lastname: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      email: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$')]],
      phonenumber: ['', [Validators.required, Validators.pattern("^[0-9]{10,12}$")]],

    });
    console.log(this.data);
    this.Useredit()
  }

  Useredit() {
    this.loading = true;
    console.log();
    this._AdminService.getUserById(this.data)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.userdetails = res?.responseMessage;
          this.edituserGroup.get('firstname').setValue(this.userdetails.firstname);
          this.edituserGroup.get('lastname').setValue(this.userdetails.lastname);
          this.edituserGroup.get('email').setValue(this.userdetails.email);
          this.edituserGroup.get('phonenumber').setValue(this.userdetails.phonenumber);
          console.log(this.userdetails);

        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }

  Updateuser() {
    this.loading = true;
    if (this.edituserGroup?.value.firstname.trim() == '' || this.edituserGroup?.value.firstname.trim() == null ||
      this.edituserGroup?.value.lastname.trim() == '' || this.edituserGroup?.value.lastname.trim() == null ||
      this.edituserGroup?.value.email.trim() == '' || this.edituserGroup?.value.email.trim() == null ||
      this.edituserGroup?.value.phonenumber.trim() == '' || this.edituserGroup?.value.phonenumber.trim() == null
    ) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please fill the mandatory fields', options);
      this.loading = false;
      return;
    }
    if (this.edituserGroup?.controls?.phonenumber?.invalid
      || this.edituserGroup?.controls?.email?.invalid || this.edituserGroup?.controls?.firstname?.invalid || this.edituserGroup?.controls?.lastname?.invalid) {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', 'Please enter valid details', options);
      this.loading = false;
      return;
    }
    else {
      let payload = {
        "userid": this.data,
        "firstname": this.edituserGroup.value.firstname,
        "lastname": this.edituserGroup.value.lastname,
        "email": this.edituserGroup.value.email,
        "phonenumber": this.edituserGroup.value.phonenumber,
      }
      console.log(payload)
      this.loading = true;

      this._AdminService.updateUserById(payload)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res)
          if (!res.isError) {
            this.loading = false;

            this.edituserGroup.reset();
            this.dialogRef.close({ data: "yes" });
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            console.log(err)
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
    }
  }
  cancelclick() {
    this.dialogRef.close({ data: "no" });

  }
}
