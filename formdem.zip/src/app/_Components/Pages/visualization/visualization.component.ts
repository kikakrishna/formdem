import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, AbstractControl, NgForm, FormControl, FormControlName } from '@angular/forms';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { ToastService } from 'ng-uikit-pro-standard';
import { Label, Color } from 'ng2-charts';
import { AdminService } from 'src/app/_Services/admin.sevice';
import { first, retry, take, takeUntil, map, startWith } from 'rxjs/operators';
import { MatTableDataSource } from '@angular/material/table';
import { AuthenticationService } from 'src/app/_Services/authentication.service';
import { Router } from '@angular/router';

export interface PeriodicElement {
  name: string;
  ingredient: string;
  fraction: string;
  activity: string;
}
export interface PeriodicElement2 {
  name: string;
  ingredient: string;
  fraction: string;
  activity: string;
  name2: string;
  fraction2: string;
  activity2: string;
  name3: string;
  fraction3: string;
  activity3: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
  { ingredient: "API Maleate", name: '50', fraction: "0.2", activity: '0.86' },
  { ingredient: "Mannitol", name: '50', fraction: "0.2", activity: '0.86' },
  { ingredient: "Starch", name: '50', fraction: "0.2", activity: '' },
  { ingredient: "Pre gelatinized starch", name: '50', fraction: "0.2", activity: '' },
  { ingredient: "YY", name: '', fraction: "0.2", activity: '0.86' },
  { ingredient: "Sodium Stearyl Fumarate", name: '', fraction: "", activity: '' },
  { ingredient: "VV", name: '50', fraction: "0.2", activity: '' },
  { ingredient: "XX", name: '', fraction: "0.2", activity: '' },
  { ingredient: "NN", name: '50', fraction: "0.2", activity: '0.86' },
  { ingredient: "Weight of Core Tablet", name: '', fraction: "", activity: '' },
];
const ELEMENT_DATA1: PeriodicElement2[] = [
  { ingredient: "API Maleate", name: '50', fraction: "0.2", activity: '0.86', name2: '50', fraction2: "0.2", activity2: '0.86', name3: '50', fraction3: "0.2", activity3: '0.86' },
  { ingredient: "Mannitol", name: '50', fraction: "0.2", activity: '0.86', name2: '50', fraction2: "0.2", activity2: '0.86', name3: '50', fraction3: "0.2", activity3: '0.86' },
  { ingredient: "Starch", name: '50', fraction: "0.2", activity: '', name2: '50', fraction2: "0.2", activity2: '0.86', name3: '50', fraction3: "0.2", activity3: '0.86' },
  { ingredient: "Pre gelatinized starch", name: '50', fraction: "0.2", activity: '', name2: '50', fraction2: "0.2", activity2: '0.86', name3: '50', fraction3: "0.2", activity3: '0.86' },
  { ingredient: "YY", name: '', fraction: "0.2", activity: '0.86', name2: '50', fraction2: "0.2", activity2: '0.86', name3: '50', fraction3: "0.2", activity3: '0.86' },
  { ingredient: "Sodium Stearyl Fumarate", name: '', fraction: "", activity: '', name2: '', fraction2: "", activity2: '', name3: '', fraction3: "", activity3: '' },
  { ingredient: "VV", name: '50', fraction: "0.2", activity: '', name2: '50', fraction2: "0.2", activity2: '0.86', name3: '50', fraction3: "0.2", activity3: '0.86' },
  { ingredient: "XX", name: '', fraction: "0.2", activity: '', name2: '50', fraction2: "0.2", activity2: '0.86', name3: '50', fraction3: "0.2", activity3: '0.86' },
  { ingredient: "NN", name: '50', fraction: "0.2", activity: '0.86', name2: '50', fraction2: "0.2", activity2: '0.86', name3: '50', fraction3: "0.2", activity3: '0.86' },
  { ingredient: "Weight of Core Tablet", name: '', fraction: "", activity: '', name2: '', fraction2: "", activity2: '', name3: '', fraction3: "", activity3: '' },
];
@Component({
  selector: 'app-visualization',
  templateUrl: './visualization.component.html',
  styleUrls: ['./visualization.component.css']
})
export class VisualizationComponent implements OnInit {
  displayedColumns: string[] = ['ingredient', 'name', 'fraction', 'StabilityScore'];
  displayedColumns1: string[] = ['ingredient', 'name', 'fraction', 'activity', 'name2', 'fraction2', 'activity2', 'name3', 'fraction3', 'activity3'];
  // dataSource = ELEMENT_DATA;
  dataSource1 = ELEMENT_DATA1;
  aftersubmitsinglejob: boolean = false;
  singlejobvisualization: boolean = true;
  listdata: boolean = false;
  JobidForm: FormGroup;
  singlejobform: FormGroup;
  singlejobid: any;
  multijobid: any;
  jobids: any = [];
  jobid = new FormControl('', [Validators.required]);
  dataSource = new MatTableDataSource<any>([]);
  jobidsId: any;
  firstname: string;
  lastname: string;
  loading: boolean;
  data: string;

  ChangeData(valid: boolean) {

    this.singlejobvisualization = valid;
    this.singlejobform.reset();
    this.aftersubmitsinglejob = false;
    this.jobid.reset();
    this.JobidForm.reset();
  }

  public barChartOptions: ChartOptions = {

    responsive: true,
  };
  public barChartLabels: Label[] = ['0.01', '0.01', '0.01', '0.01', '0.01', '0.01', '0.01'];
  public barChartType: ChartType = 'bar';
  public barChartLegend = true;

  public barChartData: ChartDataSets[] = [
    { data: [65, 59, 80, 81, 56, 55, 40], "hoverBackgroundColor": '#004090', label: 'Series A' },
  ];

  public barChartColors: Color[] = [
    { backgroundColor: '#EDF4FD' },

  ]
  constructor(private fb: FormBuilder,
    public _formBuilder: FormBuilder,
    private toastrService: ToastService,
    private _AdminService: AdminService, public authenticationService: AuthenticationService, private router: Router) {

    this.firstname = sessionStorage.getItem("firstname");
    this.lastname = sessionStorage.getItem("lastname")

    this.JobidForm = this.fb.group({
      jobid: this.fb.array([
        this.fb.control(null)
      ])
    })

    this.JobidForm = this.fb.group({
      jobid: this.fb.array([
        this.fb.control(null)
      ])

    })

  }

  ngOnInit(): void {
    this.singlejobform = this._formBuilder.group({
      singlejobid: ['', Validators.required],
    });
    console.log(this.jobid);

    // this.JobidForm = this._formBuilder.group({
    //   multijobid: ['', Validators.required],
    // });

    this.getjobids();
  }

  getjobids() {
    this.loading = true
    this._AdminService.getjobids()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false
          console.log(res);
          this.jobids = res.responseMessage
          // this.dataSource = new MatTableDataSource(res.responseMessage);

        }
        else {
          this.loading = false
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
          // setTimeout(() => {
          //   this.toastrService.clear(),2000
          // }, 2000);

        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }

  jobname: any;
  jobidsonselect(ele) {
    console.log(ele);
    this.jobidsId = ele.value.jobid
    this.jobname = ele.value.jobname

  }
  getErrorMessage() {
    return this.jobid.hasError('required') ? 'You must select a value' :
      '';

  }

  addPhone(): void {
    (this.JobidForm.get('jobid') as FormArray).push(
      this.fb.control(null)
    );
  }
  removePhone(index) {
    (this.JobidForm.get('jobid') as FormArray).removeAt(index);
  }
  getPhonesFormControls(): AbstractControl[] {
    return (<FormArray>this.JobidForm.get('jobid')).controls
  }

  formsubmit() {
    console.log("formsubmit()");
    if (this.singlejobform.valid) {
      // if (this.singlejobid.valid) {

      console.log("validation");
      this.loading = true
      this._AdminService.getvisualtable(this.jobidsId)
        .pipe(first())
        .subscribe((res: any) => {
          if (!res.isError) {
            this.loading = false
            console.log(res);
            // this.jobids = res.responseMessage
            this.dataSource = new MatTableDataSource(res.responseMessage);

            if (res.responseMessage.length == 0) {
              this.aftersubmitsinglejob = true;
              this.listdata = true;
            } else {
              this.aftersubmitsinglejob = true;
              this.listdata = false;

            }
          }
          else {
            this.loading = false
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
            // setTimeout(() => {
            //   this.toastrService.clear(),2000
            // }, 2000);

          }
        },
          err => {
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            console.log(err);

          });
      // }
    }
    else {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please enter Job name", options);
    }
  }
  multiformformsubmit() {

    console.log("multijobformsubmit()");
    if (this.JobidForm.valid) {
      if (this.jobid.valid) {

        console.log("validation");
      }
    }
    else {
      const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
      this.toastrService.warning('', "Please enter Job name", options);
    }
  }
  send(values) {
    console.log(values);
  }
  logout() {
    this.authenticationService.logout();
    this.router.navigate(['']);
  }

  csvdownload() {
    console.log(this.jobidsId);
    this.loading = true
    this._AdminService.downloadcsv(this.jobidsId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false
          console.log(res);
          const newBlob = new Blob([res], { type: 'application/csv' });
          this.data = window.URL.createObjectURL(res);
          const file_path = this.data;
          const down = document.createElement('A') as HTMLAnchorElement;
          down.href = file_path;
          down.download = this.jobname
          document.body.appendChild(down);
          down.click();
          document.body.removeChild(down);

        }
        else {
          this.loading = false
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);

        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }

  pdfdownload() {
    console.log(this.jobidsId);
    this.loading = true
    this._AdminService.downloadpdf(this.jobidsId)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false
          console.log(res);
          const newBlob = new Blob([res], { type: 'application/csv' });
          this.data = window.URL.createObjectURL(res);
          const file_path = this.data;
          const down = document.createElement('A') as HTMLAnchorElement;
          down.href = file_path;
          down.download = this.jobname
          document.body.appendChild(down);
          down.click();
          document.body.removeChild(down);

        }
        else {
          this.loading = false
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);

        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }
}
