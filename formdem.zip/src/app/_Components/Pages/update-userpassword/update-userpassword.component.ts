import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormBuilder, Validators } from '@angular/forms';
import { AdminService } from 'src/app/_Services/admin.sevice';
import { Router } from '@angular/router';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-update-userpassword',
  templateUrl: './update-userpassword.component.html',
  styleUrls: ['./update-userpassword.component.css']
})
export class UpdateUserpasswordComponent implements OnInit {
  loading: boolean;

  constructor(public _formBuilder: FormBuilder, private _AdminService: AdminService,
    private router: Router, private dialogRef: MatDialogRef<UpdateUserpasswordComponent>, private toastrService: ToastService,
    @Inject(MAT_DIALOG_DATA) public data: any) { }
  updatepasswordform: FormGroup
  ngOnInit(): void {
    this.updatepasswordform = this._formBuilder.group({
      password: ['', [Validators.required, Validators.pattern('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{6,}$')]],
    });
    console.log(this.data);
  }

  cancelclick(){
    this.dialogRef.close({ data: "no" });
  }
  Updatepassword() {
    console.log("submit")
    if (this.updatepasswordform?.value.password.trim() == '' || this.updatepasswordform?.value.password.trim() == null 
  ) {
    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    this.toastrService.warning('', 'Please fill the mandatory fields', options);
    this.loading = false;
    return;
  }
  else if(this.updatepasswordform?.controls?.password?.invalid){
    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    this.toastrService.warning('', 'Please enter valid details', options);
    this.loading = false;
    return;
  }
  else {
    let payload = {
      "user_id": this.data,
      "password": this.updatepasswordform.value.password,
    }
    console.log(payload)
    this.loading = true;

    this._AdminService.updateUserPassword(payload)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        
         if (!res.error) {
          this.loading = false;
          this.updatepasswordform.reset();
          this.dialogRef.close({ data: "yes" });
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.success('', res.responseMessage, options);
        }
         else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          console.log(err)
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        })
  }

  }
}

