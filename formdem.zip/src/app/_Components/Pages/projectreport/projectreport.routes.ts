import { RouterModule } from "@angular/router";
import { ProjectreportComponent } from "./projectreport.component";


export const ProjectreportRoutes: RouterModule [] = [
    {
        path: '',
        component: ProjectreportComponent
    }
]