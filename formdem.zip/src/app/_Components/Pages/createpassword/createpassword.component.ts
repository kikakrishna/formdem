import { Component, OnInit } from '@angular/core';

import { FormBuilder, FormGroup, FormArray, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-createpassword',
  templateUrl: './createpassword.component.html',
  styleUrls: ['./createpassword.component.css']
})
export class CreatepasswordComponent implements OnInit {
  Createpassword: FormGroup;
  constructor(private formBuilder: FormBuilder,) { }

  ngOnInit(): void {
    this.Createpassword = this.formBuilder.group({
      password: ['', [Validators.required, Validators.minLength(4), Validators.pattern('^.{4,}$')]],
    });
  }

}
