import { RouterModule } from "@angular/router";
import { StatistictoolsComponent } from "./statistictools.component";
export const StatistictoolsRoutes: RouterModule [] = [
    {
        path: '',
        component: StatistictoolsComponent
    }
]