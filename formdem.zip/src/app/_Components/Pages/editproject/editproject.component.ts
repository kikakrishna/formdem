import { Component, OnInit ,Inject } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormBuilder, Validators } from '@angular/forms';
import { AdminService } from 'src/app/_Services/admin.sevice';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';
import { MatDialogRef,MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-editproject',
  templateUrl: './editproject.component.html',
  styleUrls: ['./editproject.component.css']
})
export class EditprojectComponent implements OnInit {
  maxDate: any;
  myStartDate: any;
  loading: boolean;
  projectDetails: any;
  Status: any;
  ProjectID: any;
  
  constructor(public _formBuilder: FormBuilder,  private toastrService: ToastService,
    private _AdminService: AdminService,private dialogRef: MatDialogRef<EditprojectComponent>, @Inject(MAT_DIALOG_DATA) public data: any) { }
  editprojectGroup:FormGroup
  
  ngOnInit(): void {
    this.editprojectGroup = this._formBuilder.group({
      Name: ['',[Validators.required]],
      Code: ['',[Validators.required]],
      Sponsor: ['',[Validators.required]],
      Date: ['',[Validators.required]],
      startdate: ['',[Validators.required]],
      Status: ['',[Validators.required]],
    });

    this.myStartDate = new Date();
   this.getstatus()
   console.log(this.data);
  
this.projectedit()
  }
  getstatus() {
    this.loading = true
    this._AdminService.getstatus()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res);
          this.loading = false
          this.Status = res.responseMessage
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }
  projectedit() {
    this.loading = true;
    console.log();
    this._AdminService.getProjectById(this.data)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false;
          this.projectDetails = res?.responseMessage;
          this.editprojectGroup.get('Name').setValue(this.projectDetails.Project_Name);
          this.editprojectGroup.get('Code').setValue(this.projectDetails.Project_Code);
          this.editprojectGroup.get('Sponsor').setValue(this.projectDetails.Sponsor);
          this.editprojectGroup.get('startdate').setValue(this.projectDetails.Start_Date);
          // this.editprojectGroup.get('Status').setValue(this.projectDetails.Status);
          this.editprojectGroup.get('Status').setValue(this.projectDetails.Status);
          console.log(this.projectDetails.Status);


        } else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
  }
 
  Updateproject() {
    this.loading = true;
    if (this.editprojectGroup?.value.Name.trim() == '' || this.editprojectGroup?.value.Name.trim() == null ||
    this.editprojectGroup?.value.Code.trim() == '' || this.editprojectGroup?.value.Code.trim() == null ||
    this.editprojectGroup?.value.Sponsor.trim() == '' || this.editprojectGroup?.value.Sponsor.trim() == null
   ) 
  {
    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    this.toastrService.warning('', 'Please fill the mandatory fields', options);
    this.loading = false;
    return;
  }
  else if(this.editprojectGroup?.value?.startdate == ''){
    const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
    this.toastrService.warning('', 'Please select startdate', options);
    this.loading = false;
    return;
  }
else if(this.editprojectGroup?.value?.Status == ''){
  const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
  this.toastrService.warning('', 'Please select status', options);
  this.loading = false;
  return;
}
    else {
      let payload = {
        // "UserId": this.UserID,
        "Project_Name": this.editprojectGroup.value.Name,
        "Project_Code": this.editprojectGroup.value.Code,
        "Sponsor": this.editprojectGroup.value.Sponsor,
        "Start_Date": this.editprojectGroup.value.startdate,
        // "Password":"!Q2w3e4r",
        "Status": this.editprojectGroup.value.Status,
      }
      console.log(payload)
      this.loading = true
      this._AdminService.updateProjectById(payload,this.data)
        .pipe(first())
        .subscribe((res: any) => {
          console.log(res)
          if (!res.isError) {
            this.loading = false;
            // setTimeout(() => {
            //   // this.dataSource.paginator = this.stockinlistpaginator
            //   this.totalSize = res?.pagination?.total;
            // });

            this.editprojectGroup.reset();
            this.dialogRef.close({ data: "yes" });
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.success('', res.responseMessage, options);
            // this.PharmacyUserList()
            // this.clearfilter()
            // setTimeout(() => {
            //   this.totalSize = res?.pagination?.total;
            //   this.dataSource.paginator = this.paginator
            // });
           

          } else {
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', res.errorMessage, options);
          }
        },
          err => {
            console.log(err)
            this.loading = false;
            const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
            this.toastrService.warning('', err?.error, options);
          })
    }
  }

  cancelclick(){
    this.dialogRef.close({ data: "no" });

  }
}


