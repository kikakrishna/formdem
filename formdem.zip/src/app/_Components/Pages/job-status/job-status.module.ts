import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { JobStatusComponent } from './job-status.component';
import { JobStatusRoutes } from './job-status.routes';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import {MatSelectModule} from '@angular/material/select';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginatorModule } from '@angular/material/paginator';
@NgModule({
  declarations: [JobStatusComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(JobStatusRoutes),
    MatCardModule,
    MatTableModule,
    MatButtonModule,
    MatSelectModule,
    MatMenuModule,
    MatIconModule,
    MatPaginatorModule,

  ]
})
export class JobStatusModule { }