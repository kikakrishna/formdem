import { RouterModule } from "@angular/router";
import { JobStatusComponent } from "./job-status.component";
export const JobStatusRoutes: RouterModule [] = [
    {
        path: '',
        component: JobStatusComponent
    }
]