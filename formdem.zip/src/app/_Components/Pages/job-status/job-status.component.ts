import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { AuthenticationService } from 'src/app/_Services/authentication.service';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/_Services/admin.sevice';
import { first } from 'rxjs/operators';
import { ToastService } from 'ng-uikit-pro-standard';
import * as moment from 'moment';
import { listLazyRoutes } from '@angular/compiler/src/aot/lazy_routes';

export interface PeriodicElement {
  // id: number;
  jobname: string;
  author: string;
  submissiondate:string;
  jobstatus: string;
 
}

const ELEMENT_DATA: PeriodicElement[] = [
  // {id: 1, jobname: 'SP-P1-25C-75RH', author:'Maheshwari K',  submissiondate:'30-03-2023', jobstatus: 'Algorithm 2 is running' },
  // {id: 2, jobname: 'SP-P1-25C-75RH', author:'Maheshwari K',  submissiondate:'30-03-2023', jobstatus: 'Algorithm 2 is running' },
  // {id: 3, jobname: 'SP-P1-25C-75RH', author:'Maheshwari K',  submissiondate:'30-03-2023', jobstatus: 'Algorithm 2 is running' },
  // {id: 4, jobname: 'SP-P1-25C-75RH', author:'Maheshwari K',  submissiondate:'30-03-2023', jobstatus: 'Algorithm 2 is running' },
  // {id: 5, jobname: 'SP-P1-25C-75RH', author:'Maheshwari K',  submissiondate:'30-03-2023', jobstatus: 'Algorithm 2 is running'},
  // {id: 6, jobname: 'SP-P1-25C-75RH', author:'Maheshwari K',  submissiondate:'30-03-2023', jobstatus: 'Algorithm 2 is running' },
  // {id: 7, jobname: 'SP-P1-25C-75RH', author:'Maheshwari K',  submissiondate:'30-03-2023', jobstatus: 'Algorithm 2 is running' },
  // {id: 8, jobname: 'SP-P1-25C-75RH', author:'Maheshwari K',  submissiondate:'30-03-2023', jobstatus: 'Algorithm 2 is running' },
];


@Component({
  selector: 'app-job-status',
  templateUrl: './job-status.component.html',
  styleUrls: ['./job-status.component.css']
})

export class JobStatusComponent implements OnInit {
  displayedColumns: string[] = [  'jobname','author','submissiondate','jobstatus' ];
  // dataSource = ELEMENT_DATA;
  dataSource = new MatTableDataSource<any>([]);
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('paginator', { static: false }) joblistpaginator: MatPaginator;
  public filerpastform_pagination_show: boolean;
  //  public jobstatus: any = new MatTableDataSource([]);
  public totalSize = 10;
  public pageindex = 0;
  filterData: boolean;
  firstname: string;
  lastname: string;
  joblist: any;
  loading: boolean;
  nolist: boolean
  constructor(public authenticationService: AuthenticationService,private router: Router,
    private _AdminService: AdminService, private toastrService: ToastService) {
    this.firstname = sessionStorage.getItem("firstname") ;
    this.lastname = sessionStorage.getItem("lastname")
   }

  ngOnInit(): void {
    this.getjobstatus()
    this.dataSource.paginator = this.paginator
    
  }
  logout() { 
    this.authenticationService.logout();
    this.router.navigate(['']);
  }
  getjobstatus() {
    this.loading = true
    this._AdminService.getjoblist(this.pageindex,this.totalSize)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res);
          this.loading = false
          let array = [];
          this.totalSize = res?.responseMessage.count;
           this.joblist = res?.responseMessage.list
          this.dataSource = new MatTableDataSource(array);
          this.totalSize = res?.responseMessage.count;
          for(let item of res?.responseMessage.list) {
            let d = new Date(item?.submissiondate);
              item.submissiondate = moment(d).format('MMMM D, YYYY');
              array.push(item);
          }
          if (array.length == 0) {
            this.nolist = true;
          } else {
            this.nolist = false;

          }
          // setTimeout(() => {
          //   // this.dataSource.paginator = this.paginator
          // });
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }
  getNext(event) {
    this.loading = true;
    let array = [];
    this._AdminService.getjoblist(event.pageIndex, event.pageSize)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        if(!res.isError) {
          this.loading = false;
          this.joblist = res?.responseMessage.list;
          this.dataSource = new MatTableDataSource(array);
          for(let item of res?.responseMessage.list) {
            let d = new Date(item?.submissiondate);
              item.submissiondate = moment(d).format('MMMM D, YYYY');
              array.push(item);
          }

          if (array.length == 0) {
            this.nolist = true;
          } else {
            this.nolist = false;

          }
        }
        else {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          this.loading = false;
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', err?.error, options);
        });
      }
}
