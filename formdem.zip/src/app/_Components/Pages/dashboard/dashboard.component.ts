import { Component, OnInit, ViewChild } from '@angular/core';
import { AuthenticationService } from 'src/app/_Services/authentication.service';
import { MsalService, MsalBroadcastService, MSAL_GUARD_CONFIG, MsalGuardConfiguration } from '@azure/msal-angular';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/_Services/admin.sevice';
import { ToastService } from 'ng-uikit-pro-standard';
import { first } from 'rxjs/operators';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import * as moment from 'moment';

export interface PeriodicElement1 {
  id: number;
  projectname: string;
  projectcode: string;
  startdate: string;
  sponsor: string;
  action: string;
}

const PROJECT_DATA: PeriodicElement1[] = [
  { id: 1, projectname: 'P00-PTR-ST-01 STUDY', projectcode: 'PROJ-011', startdate: '04-04-2023', sponsor: 'Kamaraj', action: '' },
  { id: 2, projectname: 'P00-PTR-ST-01 STUDY', projectcode: 'PROJ-012', startdate: '05-04-2023', sponsor: 'Kamaraj', action: '' },
  { id: 3, projectname: 'P00-PTR-ST-01 STUDY', projectcode: 'PROJ-013', startdate: '06-04-2023', sponsor: 'Kamaraj', action: '' },
  { id: 4, projectname: 'P00-PTR-ST-01 STUDY', projectcode: 'PROJ-014', startdate: '07-04-2023', sponsor: 'Kamaraj', action: '' },
  { id: 5, projectname: 'P00-PTR-ST-01 STUDY', projectcode: 'PROJ-015', startdate: '08-04-2023', sponsor: 'Kamaraj', action: '' },

];

export interface PeriodicElement2 {
  id: number;
  jobdescription: string;
  author: string;
  submissiondate: string;
  jobstatus: string;
  action: string;
}

const JOB_DATA: PeriodicElement2[] = [
  { id: 1, jobdescription: 'SP-P1-25C-75RH', author: 'Maheshwari K', submissiondate: '04-04-2023', jobstatus: 'Completed', action: '' },
  { id: 2, jobdescription: 'SP-P1-25C-75RH', author: 'Maheshwari K', submissiondate: '04-04-2023', jobstatus: 'Completed', action: '' },
  { id: 3, jobdescription: 'SP-P1-25C-75RH', author: 'Maheshwari K', submissiondate: '04-04-2023', jobstatus: 'Completed', action: '' },


];


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  displayedColumns1: string[] = ['projectname', 'projectcode', 'startdate', 'sponsor', 'action'];
  // projectdataSource = PROJECT_DATA;
  // @ViewChild(MatPaginator) paginator: MatPaginator;
  projectdataSource = new MatTableDataSource<any>([]);
  jobdataSource = new MatTableDataSource<any>([]);
  // @ViewChild('paginator', { static: false }) joblistpaginator: MatPaginator;
  displayedColumns2: string[] = ['jobdescription', 'author', 'submissiondate', 'jobstatus', 'action'];
  // jobdataSource = JOB_DATA;
  firstname: string;
  lastname: string;
  loading: boolean;
  projectlist: any;
  jobstatus: any;
  jobcount: any;
  projectcount: any;
  pendingjobs: any;
  paramprojectid: any;
  //  public jobstatus: any = new MatTableDataSource([]);
  data: any;
  constructor(public authenticationService: AuthenticationService, private router: Router,
    private _AdminService: AdminService, private toastrService: ToastService,
    public _activatedRoute: ActivatedRoute,) {
    this.firstname = sessionStorage.getItem("firstname");
    this.lastname = sessionStorage.getItem("lastname")
  }

  ngOnInit(): void {


    this.getprojectdashboard()
  }
  logout() {
    this.authenticationService.logout();
    this.router.navigate(['']);
  }

  getprojectdashboard() {
    this.loading = true
    this._AdminService.getprojectdashboard()
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          console.log(res);
          this.loading = false
          let array = [];
          let arrayvalue = [];
          // this.totalSize = res?.responseMessage.count;
          this.jobcount = res?.responseMessage.JobCount;
          this.projectcount = res?.responseMessage.ProjectCount;
          this.pendingjobs = res?.responseMessage.PendingJobsCount;
          console.log(this.jobcount);
          this.projectlist = res?.responseMessage.ProjectList
          this.jobstatus = res?.responseMessage.Jobstatus
          this.projectdataSource = new MatTableDataSource(array);
          this.jobdataSource = new MatTableDataSource(arrayvalue);
          for (let item of res?.responseMessage.ProjectList) {
            let d = new Date(item?.Startdate);
            item.Startdate = moment(d).format('MMMM D, YYYY');
            array.push(item);
          }
          for (let item of res?.responseMessage.Jobstatus) {
            let d = new Date(item?.submissiondate);
            item.submissiondate = moment(d).format('MMMM D, YYYY');
            arrayvalue.push(item);
          }
          // setTimeout(() => {
          //   // this.dataSource.paginator = this.paginator
          // });
        }
        else {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);
        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }

  pdfdownload(ele) {
    console.log(ele);
    this.loading = true
    this._AdminService.downloadpdf(ele.jobid)
      .pipe(first())
      .subscribe((res: any) => {
        if (!res.isError) {
          this.loading = false
          console.log(res);
          const newBlob = new Blob([res], { type: 'application/csv' });
          this.data = window.URL.createObjectURL(res);
          const file_path = this.data;
          const down = document.createElement('A') as HTMLAnchorElement;
          down.href = file_path;
          down.download = ele.jobdescription
          document.body.appendChild(down);
          down.click();
          document.body.removeChild(down);

        }
        else {
          this.loading = false
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          this.toastrService.warning('', res.errorMessage, options);

        }
      },
        err => {
          const options = { opacity: 1, timeOut: 2000, tapToDismiss: true };
          console.log(err);

        });
  }

}
