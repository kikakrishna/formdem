import { Component, HostListener, OnInit } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";
import { fromEvent, merge, Observable, Observer, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
declare var $: any;


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'adminpanel';
  public onlineEvent: Observable<Event>;
  public offlineEvent: Observable<Event>;
  public subscriptions: Subscription[] = [];
  public connectionStatusMessage: string;
  public connectionStatus: string;
  constructor(public spinner: NgxSpinnerService) { }
  ngOnInit() {
    this.onlineEvent = fromEvent(window, 'online');
    this.offlineEvent = fromEvent(window, 'offline');
    this.subscriptions.push(this.onlineEvent.subscribe(event => {
      this.connectionStatusMessage = 'Connected to internet! You are online';
      this.connectionStatus = 'online';
      // alert("online")
      this.spinner.hide();
    }));
    this.subscriptions.push(this.offlineEvent.subscribe(e => {
      this.connectionStatusMessage = 'Connection lost! You are offline';
      this.connectionStatus = 'offline';
      // alert("offline")
      this.spinner.show();
    }));
    if (sessionStorage.getItem('Role') != "admin") {
      // const body = document.getElementsByTagName('body')[0];
      // body.classList.add('noselect');
      $('body').addClass('noselect');
    }else{
      $('body').removeClass('noselect');

    }
  }

}
